import ServicePage from ".";
import { HocLayzy } from "@/admin-react-app/reduxes/hoc.lazy";
import { AppDispatch, RootState } from "@/admin-react-app/reduxes/types";
import { connect } from 'react-redux';
import { TServiceReduxProps, TServiceReduxState } from "./types";
import { fetchServiceThunk } from "./redux.thunks";
import ServiceSlice from "./redux.slice";
import { Sleep } from "@/modules/Library/Helpers";
export const HocComp = HocLayzy(ServicePage)()

const mapStateToProps = (state: RootState): TServiceReduxState => ({
    data: state.serviceSlice.data.entities,
    status: state.serviceSlice.status
})

const mapDispatchToProps = (dispatch: AppDispatch): TServiceReduxProps => {
    return {
        FetchData(...param) {
            return dispatch(fetchServiceThunk())
        },
        async Create(model) {
            await Sleep(1000)
            dispatch(ServiceSlice.actions.Add(model))
        },
        async Delete(Id, model) {
            await Sleep(1000)
            dispatch(ServiceSlice.actions.Remove(Id))
        },
        async Update(Id, model) {
            await Sleep(1000)
            dispatch(ServiceSlice.actions.Update({
                id: Id,
                changes: model ?? {}
            }))
        },
    }
}

export const ReduxService = connect(mapStateToProps, mapDispatchToProps)(HocComp)
