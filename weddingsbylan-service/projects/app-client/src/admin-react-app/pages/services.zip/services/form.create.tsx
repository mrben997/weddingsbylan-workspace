import { IService } from "@/admin-react-app/model";
import { IFormBase } from "@/modules/Library/Forms";
import { FC } from "react";
import { FormInstance } from "./form";
interface IFormCreateProps {
    onSubmit: (data: Partial<IService>) => Promise<void>
    title: string
}
export const FormCreate: FC<IFormCreateProps> = (props) => {
    return <FormInstance.Form title={props.title} onSubmit={props.onSubmit} />
}