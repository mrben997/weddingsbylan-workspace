import { IService } from "@/admin-react-app/model";
import CreateForm from "@/modules/Library/FormHelpers/CreateForm";
import { FormValidator, IFormBase } from "@/modules/Library/Forms";
import { FC } from "react";

interface IFormInfoProps extends IFormBase<IService> { }
const FormInfo: FC<IFormInfoProps> = () => {
    return <></>
}

var formValidate = new FormValidator<Partial<IService>>({

})
export const FormInstance = CreateForm(formValidate, FormInfo)

