import { IService } from "@/admin-react-app/model";
import { CRUDActionReduxType, IReduxDispatch, IReduxState } from "@/admin-react-app/reduxes/types";

export type TServiceReduxState = {} & IReduxState<string, IService>
export type TServiceReduxProps = {} & IReduxDispatch & CRUDActionReduxType<IService, 'Id'>

interface IServiceProps { }
export type TServiceProps = TServiceReduxState & TServiceReduxProps & IServiceProps