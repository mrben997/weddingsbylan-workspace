import { IService } from "@/admin-react-app/model"
import { RootState } from "@/admin-react-app/reduxes/types"
import { createAsyncThunk } from "@reduxjs/toolkit"

interface IParamThunk { }
// interface IResponse { }
export const fetchServiceThunk = createAsyncThunk<IService[], IParamThunk | undefined>('fetchServiceThunk', async (param, thunkAPI) => {
    const state = thunkAPI.getState() as RootState
    return Promise.resolve([{
        Id: '1',
        Name: 'New 1'
    },
    {
        Id: '2',
        Name: 'New 2'
    }])
})