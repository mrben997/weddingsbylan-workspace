import { Component } from "react";
import { TServiceProps } from "./types";
import { DictToListNotNull } from "@/admin-react-app/ultilities/helper";
import { ActionPannel, CreateTableTemplate, CRUDPannel } from "@/modules/Library/Table";
import { IService } from "@/admin-react-app/model";
import { FormCreate } from "./form.create";
import { FormEdit } from "./form.edit";
import { FormDelete } from "./form.delete";

const Table = CreateTableTemplate<IService>("Client", {
    getRowId: (x: IService) => x.Id,
    config: {
        Id: {},
        Name: {}
    }
})
interface IServicePageState {
    loading: boolean
}
class ServicePage extends Component<TServiceProps, IServicePageState> {
    constructor(props: TServiceProps) {
        super(props)
        this.state = {
            loading: false
        }
    }
    onCreate = async (data: Partial<IService>) => {
        await this.props.Create(data)
    }
    onEdit = async (data: Partial<IService>) => {
        data?.Id && await this.props.Update(data.Id, data)
    }
    onDetele = async (data?: IService) => {
        if (data?.Id) {
            try {
                this.setState({ loading: true })
                await this.props.Delete(data.Id)
            } catch (error) {

            } finally {
                this.setState({ loading: false })
            }
        }
    }
    render() {
        return (
            <Table
                InnerProps={{
                    loading: this.state.loading
                }}
                CRUDPannel={p => <CRUDPannel Create={<FormCreate title="New" onSubmit={this.onCreate} />} />}
                data={DictToListNotNull(this.props.data)}
                ActionPannel={p =>
                    <ActionPannel
                        Edit={<FormEdit title="Edit" data={p.data} onSubmit={this.onEdit} />}
                        Delete={<FormDelete data={p.data} onSubmit={this.onDetele} />}
                    />
                }
            />
        );
    }
}

export default ServicePage;