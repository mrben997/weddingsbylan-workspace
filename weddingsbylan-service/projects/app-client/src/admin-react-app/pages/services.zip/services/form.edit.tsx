import { IService } from "@/admin-react-app/model";
import { IFormBase } from "@/modules/Library/Forms";
import { FC } from "react";
import { FormInstance } from "./form";

interface IFormEditProps {
    onSubmit: (data: Partial<IService>) => Promise<void>
    title: string
    data: IService
}
export const FormEdit: FC<IFormEditProps> = (props) => {
    return <FormInstance.Form onSubmit={props.onSubmit} title={props.title} data={props.data} />
}